#pragma once
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

const int COL_WIDTH = 20;